import java.util.*;

public class TestArrays
{
	public static void main(String[] args)
	{
		MyArrayList<Integer> Array1 = new MyArrayList<>();
		
		Array1.add(0,new Integer(1));
		Array1.add(1,new Integer(3));
		Array1.add(2,new Integer(5));
		Array1.add(3,new Integer(13));
		Array1.add(4,new Integer(30));
		Array1.sortList();
		
		System.out.println("When value is Inseted");
		Array1.InsertSorted(new Integer(2));
		System.out.println(Array1);
		
		System.out.println("\nWhen value is the largest");
		Array1.InsertSorted(new Integer(31));
		System.out.println(Array1);
		
		System.out.println("\nWhen value is the smalers");
		Array1.InsertSorted(new Integer(0));
		System.out.println(Array1);
		
		System.out.println("\nWhen value is the same");
		Array1.InsertSorted(new Integer(5));
		System.out.println(Array1);
		
		MyArrayList<Integer> Array2 = new MyArrayList<>();
		
		Array2.sortList();
		//if you want to test 100 plus 1 value coment out the code below
		System.out.println("When no values are in list");
		Array2.InsertSorted(new Integer(2));
		System.out.println(Array2);
		
		for (int i = 0; i < 100; i++)
		{
			Array2.add(i,new Integer(i));
		}
		
		System.out.println("When 100 values are in list and you insert a value");
		Array2.InsertSorted(new Integer(2));
		System.out.println(Array2);
	}
}