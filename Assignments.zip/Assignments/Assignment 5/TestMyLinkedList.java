public class TestMyLinkedList {
  public static void main(String[] args) {
   
   boolean done = false;
   MyLinkedList<Integer> list = new MyLinkedList<Integer>();
	
	System.out.println("\nInsert into empty list:");
	list.insertSorted(new Integer(0));
	System.out.println(list);
	
    // Add elements to the list
    list.append(new Integer(1));
    list.append(new Integer(3));
    list.append(new Integer(5));
    list.append(new Integer(7)); 
	list.append(new Integer(9));
    list.append(new Integer(11));
	list.append(new Integer(13));
	
	System.out.println("\nList:");
	System.out.println(list);
	System.out.println("Insert inbetween:");
	list.insertSorted(new Integer(9));
    System.out.println(list);

	System.out.println("\nList:");
	System.out.println(list);
	System.out.println("Insert smaller:");
	list.insertSorted(new Integer(-1));
    System.out.println(list);
		
	System.out.println("\nList:");
	System.out.println(list);
	System.out.println("Insert larger:");
    list.insertSorted(new Integer(21));
    System.out.println(list);
  }
}


