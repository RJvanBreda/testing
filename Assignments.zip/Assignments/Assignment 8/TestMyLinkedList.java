public class TestMyLinkedList {
  public static void main(String[] args) {
   
   boolean done = false;
   MyLinkedList<Integer> list = new MyLinkedList<Integer>();
	
	System.out.println("Work with empty list:");
	System.out.println(list.binarySearch(list, new Integer(3)));

    // Add elements to the list
	list.append(new Integer(3));
    list.append(new Integer(5));
    list.append(new Integer(7));
    list.append(new Integer(8)); 
	list.append(new Integer(12));
    list.append(new Integer(17));
	list.append(new Integer(24));
	list.append(new Integer(29));
	
	System.out.println("\nList:");
	System.out.println(list);
	System.out.println("Find key 7:");
    System.out.println("Found: " + list.binarySearch(list, new Integer(7)));
	
	list.clear();
	
	list.append(new Integer(3));
    list.append(new Integer(5));
    list.append(new Integer(7));
    list.append(new Integer(8)); 
	list.append(new Integer(12));
    list.append(new Integer(17));
	list.append(new Integer(24));
	list.append(new Integer(29));
	
	System.out.println("\nList:");
	System.out.println(list);
	System.out.println("Find key 0:");
    System.out.println("Found: " + list.binarySearch(list, new Integer(0)));
	
	list.clear();
	
	list.append(new Integer(3));
    list.append(new Integer(5));
    list.append(new Integer(7));
    list.append(new Integer(8)); 
	list.append(new Integer(12));
    list.append(new Integer(17));
	list.append(new Integer(24));
	list.append(new Integer(29));
	
	System.out.println("\nList:");
	System.out.println(list);
	System.out.println("Find key 50:");
    System.out.println("Found: " + list.binarySearch(list, new Integer(50)));
  }
}


