public class Assignment7
{
	public static int power(int basis, int tor)
	{
		if (tor == 0)
		{
			return 1;
		}
		else
		{
			return basis * power(basis, tor - 1);
		}
	}
	
	public static void main(String[] args)
	{
		System.out.println("Special case test");
		System.out.println(power(13,0));
		System.out.println("Normal test of power method");
		System.out.println(power(3,3));
	}
}
