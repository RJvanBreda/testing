import java.util.*;

public class TestUsers
{
	public static final int MAX_NO_THINGS = 5;
	
	public static void main(String[] args)
	{
		MyArrayList<CellUsers> stuff = new MyArrayList<>();
		PrepaidUsers p1 = new PrepaidUsers("Igee", "DoringHoekPlot", "Tabazimbi", "001", "MTN", "0837760687", 100, 20, 120);
		ContractUsers c1 = new ContractUsers("Tegan", "DoringHoekPlot", "Tabazimbi", "001", "MTN", "12345678", "New User", "Samsung Galesy 9", 100, 50);
		PrepaidUsers p2 = new PrepaidUsers("Gert", "7de Laan", "pretoria", "002", "Vodakom", "10864572", 80, 20, 100);
		ContractUsers c2 = new ContractUsers("Kevin", "DoringHoekPlot", "Tabazimbi", "001", "Cell C", "87548672", "Old User", "Samsung Galesy 8", 50, 20);
		PrepaidUsers p3 = new PrepaidUsers("Tim", "8de Laan", "Durban", "001", "Vodakom", "86738267", 50, 150, 200);

		stuff.add(0,p1);
		stuff.add(1,c1);
		stuff.add(2,p2);
		stuff.add(3,c2); 
		stuff.add(4,p3);
		
		if (stuff.sortList())
		{
			System.out.println(stuff);
		}
	}
}