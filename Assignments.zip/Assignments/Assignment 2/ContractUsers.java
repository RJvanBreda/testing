import java.util.Date;

public class ContractUsers extends CellUsers
{
	private Date contractStartDate;
	private String contractDescription;
	private String phoneDescription;
	private double freeMinutesLeft;
	private double freeSMSsLeft;
	
	protected ContractUsers()
	{
		this("", "", "", "", "", "", "", "", 0, 0);
	}
	
	protected ContractUsers(String name, String adressLine1, String adressLine2, String postalCode, String serviceProvider, String cellNum, String contractDescription, String phoneDescription, double freeMinutesLeft, double freeSMSsLeft)
	{
		super(name, adressLine1, adressLine2, postalCode, serviceProvider, cellNum);
		setContractDescription(contractDescription);
		setPhoneDescription(phoneDescription);
		setFreeMinutesLeft(freeMinutesLeft);
		setFreeSMSsLeft(freeSMSsLeft);
		contractStartDate = new Date();
	}
	
	public void setContractDescription(String contractDescription)
	{
		this.contractDescription = contractDescription;
	}
	
	public void setPhoneDescription(String phoneDescription)
	{
		this.phoneDescription = phoneDescription;
	}
	
	public void setFreeMinutesLeft(double freeMinutesLeft)
	{
		this.freeMinutesLeft = freeMinutesLeft;
	}
	
	public void setFreeSMSsLeft(double freeSMSsLeft)
	{
		this.freeSMSsLeft = freeSMSsLeft;
	}
	
	public String getContractDescription()
	{
		return contractDescription;
	}
	
	public String getPhoneDescription()
	{
		return phoneDescription;
	}
	
	public double getFreeMinutesLeft()
	{
		return freeMinutesLeft;
	}
	
	public double getFreeSMSsLeft()
	{
		return freeSMSsLeft;
	}
	
	public Date getContractStartDate()
	{
		return contractStartDate;
	}
	
	public String showAccount()
	{
		return "Show Acount: " + "\nName: " + this.getName() + "\nService Provider: " + this.getServiceProvider() + "\nCell Number: " + this.getCellNum() + "\n";
	}
	
	public String toString()
	{
		return "Name: " + getName() + "\t" + "Minnits: " + getFreeMinutesLeft() + "\n";
	}
	
	public int compareTo(CellUsers g) 
	{
		if(this.getClass().equals(g.getClass()))
		{
			ContractUsers c = (ContractUsers)g;   
			if (this.getFreeMinutesLeft() == c.getFreeMinutesLeft())
			{
				return 0;
			}
			else if (this.getFreeMinutesLeft() < c.getFreeMinutesLeft())
			{
				return -1;
			}
			else
			{
				return 1;
			}
		}
		else
		{
			return this.getClass().getName().compareTo(g.getClass().getName());
		}  
	}
}