public abstract class CellUsers implements Comparable<CellUsers>
{
	private String name;
	private String adressLine1;
	private String adressLine2;
	private String postalCode;
	private String serviceProvider;
	private String cellNum;
	
	protected CellUsers()
	{
		this("", "", "", "", "", "");
	}
	
	protected CellUsers(String name, String adressLine1, String adressLine2, String postalCode, String serviceProvider, String cellNum)
	{
		setName(name);
		setAdressLine1(adressLine1);
		setAdressLine2(adressLine2);
		setPostalCode(postalCode);
		setServiceProvider(serviceProvider);
		setCellNum(cellNum);
	}
	
	public void setName(String name)
	{
		this.name = name;
	}
	
	public void setAdressLine1(String adressLine1)
	{
		this.adressLine1 = adressLine1;
	}
	
	public void setAdressLine2(String adressLine2)
	{
		this.adressLine2 = adressLine2;
	}
	
	public void setPostalCode(String postalCode)
	{
		this.postalCode = postalCode;
	}
	
	public void setServiceProvider(String serviceProvider)
	{
		this.serviceProvider = serviceProvider;
	}
	
	public void setCellNum(String cellNum)
	{
		this.cellNum = cellNum;
	}
	
	public String getName()
	{
		return name;
	}
	
	public String getAdressLine1()
	{
		return adressLine1;
	}
	
	public String getAdressLine2()
	{
		return adressLine2;
	}
	
	public String getPostalCode()
	{
		return postalCode;
	}
	
	public String getServiceProvider()
	{
		return serviceProvider;
	}
	
	public String getCellNum()
	{
		return cellNum;
	}
	
	@Override
	public String toString()
	{
		return "Name: " + this.getName() + "\nCell Number: " + this.getCellNum();
	}
	
	public abstract String showAccount();
}