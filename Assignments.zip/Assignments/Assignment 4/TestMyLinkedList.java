public class TestMyLinkedList 
{
	public static void main(String[] args) 
	{
		boolean done = false;
		MyLinkedList<Integer> list = new MyLinkedList<Integer>();
		MyLinkedList<Integer> list2nd = new MyLinkedList<Integer>();
		
		// test empty list
		System.out.println("\nRemove from empty list");
		System.out.println(list);
		System.out.println(list.delete(new Integer(6)));
		System.out.println(list);
		
		System.out.println("\nList is Empty: isMember() test");
		System.out.println(list);
		System.out.println(list.isMember(5));
		
		System.out.println("\nBoth list are emty: missing() test");
		System.out.println(list.missing(list2nd));
		
		// Add elements to the list
		list.append(new Integer(6));
		list.append(new Integer(5));
		list.append(new Integer(3));
		list.append(new Integer(4)); 
		list.append(new Integer(2));
		list.append(new Integer(5));
		list.append(new Integer(1));
		
		System.out.println("\nRemove first element");
		System.out.println(list);
		System.out.println(list.delete(new Integer(6)));
		System.out.println(list);

		// remove last element
		System.out.println("\nRemove last element");
		System.out.println(list);
		System.out.println(list.delete(new Integer(1)));
		System.out.println(list);
		//implicit call to toString()

		// remove middle element
		System.out.println("\nRemove middle element");
		System.out.println(list);
		System.out.println(list.delete(new Integer(4)));
		System.out.println(list);

		// remove invalid element
		System.out.println("\nRemove invalid element");
		System.out.println(list);
		System.out.println(list.delete(new Integer(16)));
		System.out.println(list);
	
		// isMember() test
		System.out.println("\nisMember() test");
		System.out.println(list);
		System.out.println(list.isMember(5));
		
		// missing() test

		System.out.println("\nEmty list: missing() test");
		System.out.println(list.missing(list2nd));	
		
		list2nd.append(new Integer(7));
		list2nd.append(new Integer(3));
		list2nd.append(new Integer(3));
		list2nd.append(new Integer(1)); 
		list2nd.append(new Integer(2));
		list2nd.append(new Integer(6));
		list2nd.append(new Integer(11));
		
		System.out.println("\nmissing() test");
		System.out.println(list.missing(list2nd));	
	}
}


