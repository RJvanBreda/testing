import java.util.*;

public class TestUsers
{
	public static final int MAX_NO_THINGS = 5;
	
	public static void main(String[] args)
	{
		CellUsers[] stuff = new CellUsers[MAX_NO_THINGS];
		stuff[0] = new PrepaidUsers("Igee", "DoringHoekPlot", "Tabazimbi", "001", "MTN", "0837760687", 100, 20, 120);
		stuff[1] = new ContractUsers("Tegan", "DoringHoekPlot", "Tabazimbi", "001", "MTN", "12345678", "New User", "Samsung Galesy 9", 100, 50);
		stuff[2] = new PrepaidUsers("Gert", "7de Laan", "pretoria", "002", "Vodakom", "10864572", 80, 20, 100);
		stuff[3] = new ContractUsers("Kevin", "DoringHoekPlot", "Tabazimbi", "001", "Cell C", "87548672", "Old User", "Samsung Galesy 8", 50, 20);
		stuff[4] = new PrepaidUsers("Tim", "8de Laan", "Durban", "001", "Vodakom", "86738267", 50, 150, 200);
		
		for (int i = 0; i < MAX_NO_THINGS; i++)
		{
			System.out.println(stuff[i]);
			System.out.println("--------------------------------");
			System.out.println(stuff[i].showAccount());
			System.out.println("--------------------------------");
		} 
	}
}