public class PrepaidUsers extends CellUsers
{
	private double dataBalance;
	private double minutesBalance;
	private double amountBalance;
	
	protected PrepaidUsers()
	{
		this("", "", "", "", "", "", 0, 0, 0);
	}
	
	protected PrepaidUsers(String name, String adressLine1, String adressLine2, String postalCode, String serviceProvider, String cellNum, double dataBalance, double minutesBalance, double amountBalance)
	{
		super(name, adressLine1, adressLine2, postalCode, serviceProvider, cellNum);
		setDataBalance(dataBalance);
		setMinutesBalance(minutesBalance);
		setAmountBalance(amountBalance);
	}
	
	public void setDataBalance(double dataBalance)
	{
		this.dataBalance = dataBalance;
	}
	
	public void setMinutesBalance(double minutesBalance)
	{
		this.minutesBalance = minutesBalance;
	}
	
	public void setAmountBalance(double amountBalance)
	{
		this.amountBalance = amountBalance;
	}
	
	public double getDataBalance()
	{
		return dataBalance;
	}
	
	public double getminutesBalance()
	{
		return minutesBalance;
	}
	
	public double getAmountBalance()
	{
		return amountBalance;
	}
	
	public String showAccount()
	{
		return "Show Acount: " + "\nName: " + this.getName() + "\nService Provider: " + this.getServiceProvider() + "\nCell Number: " + this.getCellNum() + "\n";
	}
	
	public String toString()
	{
		return super.toString() + "\nAmount Balance: " + getDataBalance() + "\n";
	}
}