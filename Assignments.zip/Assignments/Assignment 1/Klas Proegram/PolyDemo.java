public class PolyDemo
{
	public static void main (String[] args)
	{
		// most simple form of test
		Circle c1= new Circle (1, "red",false);
		Rectangle r1 = new Rectangle (1,2, "black",true);
		System.out.println("\n c1:"+c1); // implicit call to toString()
		System.out.println("\n r1:"+r1.toString()); // explicit call to toString()
		// somewhat more advance -> still without polymorphism
		// this is static binding - the method is called from an object (c1) of the subclass
		System.out.println("\n c1:"+c1+ " with area:"+ c1.getArea());
		System.out.println("\n r1:"+r1+ " with area:"+ r1.getArea());
		
		
		// Now let us attempt is polymorphism - the sub class method 
		//is called from a reference to the super class
		GeometricObject g1 = new Circle (3, "blue",false);
		System.out.println("\n g1:"+g1+ " with area:"+g1.getArea());
		// now for the power of this!
		//create more circles and rectangles - note their sizes this is to identify 
		//them easy later in terms of correctness of area computation
		Circle c2= new Circle (10, "red",false);
		Rectangle r2 = new Rectangle (10,2, "black",true);
		Circle c3= new Circle (100, "red",false);
		Rectangle r3 = new Rectangle (100,2, "black",true);
		Circle c4= new Circle (1000, "red",false);
		Rectangle r4 = new Rectangle (1000,2, "black",true);
		// create an array of GeometricObject
		GeometricObject shapes[] = new GeometricObject[8];
		shapes[0] = c1;
		shapes[1] = r1;
		shapes[2] = c2;
		shapes[3] = c3;
		shapes[4] = r2;
		shapes[5] = c4;
		shapes[6] = r3;
		shapes[7] = r4;
		for (int i= 0; i<8; i++)
		{
			System.out.println("\n shape[" + i +"]: "+shapes[i]+ " with area: "+ shapes[i].getArea());
		}
		// one final remark on objects
		// two objects with similar values but different addresses
		Circle c10= new Circle (1, "red",false);
		Circle c11= new Circle (1, "red",false);
		if (c10.equals(c11)) //c10 is the calling object - in the class Circle it will be the this variable
			System.out.println("\n c10== c11");
		else
			System.out.println("\n c10 != c11");
		// if the equals of Object was not overridden the else would be executed!
		
	}
}
		