public class IndexOutOfBoundsException extends RuntimeException
{
	public IndexOutOfBoundsException()
	{
		super();
	}
	
	public IndexOutOfBoundsException(String m)
	{
		super(m);
	}
}