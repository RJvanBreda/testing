public class TestStackMyLinkedList
{
  public static void main(String[] args) 
  {
		 Integer top = null;
		 Integer total = 0;
		 
		 
		 
		 StackAsMyLinkedList<Integer> myStack1 = new StackAsMyLinkedList<Integer>();
		 StackAsMyLinkedList<Integer> myStack2 = new StackAsMyLinkedList<Integer>();
		 StackAsMyLinkedList<Integer> myStack3 = new StackAsMyLinkedList<Integer>();
		 
		 System.out.println("\nWhen stack1 is empty: ");
		 System.out.println(myStack1.isEmpty() +"\n");
		 
		 System.out.println("\nWhen stack1 and stack2 is empty: ");
		 myStack3 = myStack1.addingLargeNumbers(myStack2);
		 System.out.println(myStack3 +"\n");

		 System.out.println("\nAdd a few more to Stack1:");
		 myStack1.push(new Integer(5));
		 myStack1.push(new Integer(9));
		 myStack1.push(new Integer(2));
		 System.out.println(myStack1 +" ");
		 
		 System.out.println("\nWhen stack1 is not empty: ");
		 System.out.println(myStack1.isEmpty() +"\n");
		 
		 System.out.println("\nWhen stack1 is counted and stack 2 is empty: ");
		 myStack3 = myStack1.addingLargeNumbers(myStack2);
		 System.out.println(myStack3 +"\n");
		 
		 System.out.println("\nAdd a few more to Stack1:");
		 myStack1.push(new Integer(5));
		 myStack1.push(new Integer(9));
		 myStack1.push(new Integer(2));
		 System.out.println(myStack1 +" ");

		 System.out.println("\nAdd a few more to Stack2:");
		 myStack2.push(new Integer(3));
		 myStack2.push(new Integer(7));
		 myStack2.push(new Integer(8));
		 myStack2.push(new Integer(4));
		 System.out.println(myStack2 +" ");
		 
		 System.out.println("\nWhen 2 stacks is counted: ");
		 myStack3 = myStack1.addingLargeNumbers(myStack2);
		 System.out.println(myStack3 +"\n");
	}
}